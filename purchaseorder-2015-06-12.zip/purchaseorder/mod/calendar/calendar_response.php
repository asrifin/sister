<?php
include '../../includes/session.php';
include '../../includes/config.php';
include '../../includes/fungsi.php';
include '../../includes/mysql.php';
include 'calendar_function.php';
//sleep(4);
echo $cals;
exit;
?>