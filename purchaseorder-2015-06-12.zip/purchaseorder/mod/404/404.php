<?php
if (!defined('AURACMS_MODULE')) {
    Header("Location: ../index.php");
    exit;
}
echo "<img src='mod/404/404.jpg'>";

?>