tglblnthnjammntdtk nomor inv / fk
kirim data popup bentuk char / kode supp wajib angka