<?php
define('lang_Select','Sélectionner');
define('lang_Erase','Effacer');
define('lang_Open','Ouvrir');
define('lang_Confirm_del','Êtes-vous sûr de vouloir effacer ce fichier ?');
define('lang_All','Tous');
define('lang_Files','Fichiers');
define('lang_Images','Images');
define('lang_Archives','Archives');
define('lang_Error_Upload', 'Votre fichier dépasse la taille maximum autorisée.');
define('lang_Error_extension','Extension de fichier non autorisée');
define('lang_Upload_file','Envoyer un fichier');
define('lang_Filter','Filtrez');
define('lang_Videos','Vidéos');
define('lang_Music','Musique');
define('lang_New_Folder','Nouveau dossier');
define('lang_Folder_Created','Dossier correctement créé');
define('lang_Existing_Folder','Dossier existant');
define('lang_Confirm_Folder_del','Êtes-vous sûr de vouloir supprimer le dossier ainsi que tous ses éléments ?');
define('lang_Return_Files_List','Revenir à la liste des fichiers');
define('lang_Preview','Aperçu');
define('lang_Download','Download');
define('lang_Insert_Folder_Name','Insérer le nom du dossier:');
define('lang_Root','racine');
?>
